package com.StudentAdmission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentAdmissionApplicationTests {

	@Test
	void contextLoads() {
	}

}
